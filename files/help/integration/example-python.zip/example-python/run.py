# coding: utf-8

from core import Task, execute_task, call

class ExampleTask(Task):
    """
    Example Python task
    """
    def _ping(self, target):
        """Call ping"""
        ok, out = call.call(["/bin/ping", "-c 3", target])

        if not ok:
            raise Exception("ping calling error!")

        return out

    def main(self, *args):
        """Main function"""
        self._write_result(self._ping(self.target))

    def test(self):
        """Test function"""
        self.target = "google.com"
        self.main()

execute_task(ExampleTask)


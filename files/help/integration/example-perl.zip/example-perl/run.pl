# Example Perl Script
# ---

use MooseX::Declare;
use core::task qw(execute);

# Example Perl script
class ExampleTask extends Task {
    use core::task qw(call_external);

    # Ping
    method _ping(Str $target) {
        return call_external("/bin/ping -c 3 $target");
    }

    # Main function
    method main($args) {
        $self->_write_result($self->_ping($self->target));
    }

    # Test function
    method test {
        $self->target = "google.com";
        $self->main();
    }
}

execute(ExampleTask->new());

